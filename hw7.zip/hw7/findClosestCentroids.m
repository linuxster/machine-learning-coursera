function idx = findClosestCentroids(X, centroids)
  ##FINDCLOSESTCENTROIDS computes the centroid memberships for every example
  ##   idx = FINDCLOSESTCENTROIDS (X, centroids) returns the closest centroids
  ##   in idx for a dataset X where each row is a single example. idx = m x 1 
  ##   vector of centroid assignments (i.e. each entry in range [1..K])
  ##

  d = zeros (rows (X), rows (centroids));

  ## This loop can be avoided with greater memory usage, but it doesn't
  ## seem to speed things up.
  for i = 1:rows (centroids)

    ## Using broadcasting (auto BSX) as available in Octave 3.5.0+
    d(:, i) = sum ((X - centroids(i,:)).^2, 2);

  endfor

  [~, idx] = min (d, [], 2);

endfunction
